import { config } from 'dotenv';
config();

import '@/ai/flows/validate-press-die-combination.ts';